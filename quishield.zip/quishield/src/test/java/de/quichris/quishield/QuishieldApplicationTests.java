package de.quichris.quishield;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuishieldApplicationTests {

	@Test
	void contextLoads() {
	}

}
